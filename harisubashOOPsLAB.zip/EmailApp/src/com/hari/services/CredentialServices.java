package com.hari.services;

import com.hari.model.Employee;
import com.hari.driver.Driver;

public class CredentialServices {
	 public String generatedPassword(){
		return ("qq109*-*-KA");
	}
	public String generateEmail(String firstName , String lastName, String depatrment){
		return ( firstName + lastName + "@"+ depatrment+ "abc.com");

}
	public void showCredentails(Employee employee1, String generatedEmail, char[] generatedPassword2 ) {
		System.out.println ("Dear"+ employee1.getFirstName() + " your generated credentials are as follows");
		System.out.println("Email----->"+ generatedEmail);
		System.out.println("Password ---> "+ generatedPassword());
		
		
	}
}
