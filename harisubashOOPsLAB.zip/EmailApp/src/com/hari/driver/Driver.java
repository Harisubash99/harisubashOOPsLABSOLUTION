package com.hari.driver;

import java.util.Scanner;


import com.hari.model.Employee;
import com.hari.services.CredentialServices;

public class Driver {

	public static void main(String[] args, String department) {
		Employee employee1 = new Employee("Eren","Yeager");
		CredentialServices credentials = new CredentialServices();
		String generatedEmail;
		char[] generatedPassword = null;
		System.out.println("Please enter the department from the following");
		System.out.println("1.Technical");
		System.out.println("2.Admin");
		System.out.println("3.Human Resources");
		System.out.println("4.Legal");
		
		Scanner sc = new Scanner(System.in);
		int option;
		option = sc.nextInt();
		
		switch(option)
		{
		case 1:
			generatedEmail = credentials.generateEmail(employee1.getFirstName().toLowerCase(),employee1.getLastName().toLowerCase(), "tech");
			credentials.showCredentails(employee1, generatedEmail, generatedPassword);
			break;
		case 2:
			generatedEmail = credentials.generateEmail(employee1.getFirstName().toLowerCase(),employee1.getLastName().toLowerCase(), "adm");
			credentials.showCredentails(employee1, generatedEmail, generatedPassword);
			break;
		case 3:
			generatedEmail = credentials.generateEmail(employee1.getFirstName().toLowerCase(),employee1.getLastName().toLowerCase(), "hr");
			credentials.showCredentails(employee1, generatedEmail, generatedPassword);
			break;
		case 4:
			generatedEmail = credentials.generateEmail(employee1.getFirstName().toLowerCase(),employee1.getLastName().toLowerCase(), "lg");
			credentials.showCredentails(employee1, generatedEmail, generatedPassword);
			break;
		default:
			System.out.println("Enter a vaild option");
			break;
		}
		
		
		


	}

}
